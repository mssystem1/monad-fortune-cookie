export default { reactStrictMode: true, experimental: { esmExternals: "loose" } };
