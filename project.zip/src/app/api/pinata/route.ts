// src/app/api/pinata/route.ts
import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function must(v?: string, name?: string) {
  const s = (v || "").replace(/^\uFEFF/, "").replace(/[\u200B-\u200D\uFEFF]/g, "").trim();
  if (!s) throw new Error(`Missing ${name}`);
  return s;
}

export async function POST(req: NextRequest) {
  const PINATA_JWT = must(process.env.PINATA_JWT, "PINATA_JWT");
  const GATEWAY = (process.env.PINATA_GATEWAY || "https://gateway.pinata.cloud/ipfs/").trim();

  const { base64, filename = "image.png", mime = "image/png" } = await req.json().catch(() => ({}));
  if (!base64 || typeof base64 !== "string") {
    return NextResponse.json({ error: "Missing base64" }, { status: 400 });
  }

  // Convert to Blob for form-data
  const bytes = Buffer.from(base64, "base64");
  const form = new FormData();
  form.append("file", new Blob([bytes], { type: mime }), filename);

  // Optional metadata
  form.append("pinataMetadata", new Blob([JSON.stringify({ name: filename })], { type: "application/json" }));

  try {
    const res = await fetch("https://api.pinata.cloud/pinning/pinFileToIPFS", {
      method: "POST",
      headers: { Authorization: `Bearer ${PINATA_JWT}` },
      body: form as any,
      cache: "no-store",
    });
    if (!res.ok) {
      const t = await res.text();
      throw new Error(`Pinata ${res.status}: ${t}`);
    }
    const json = await res.json();
    const cid = json?.IpfsHash;
    const ipfsUri = `ipfs://${cid}`;
    const gatewayUrl = `${GATEWAY}${cid}`;
    return NextResponse.json({ cid, ipfsUri, gatewayUrl });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || String(e) }, { status: 502 });
  }
}
