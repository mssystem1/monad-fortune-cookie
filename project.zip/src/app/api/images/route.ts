// src/app/api/images/route.ts
import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function key() {
  const KEY_NAME = (process.env.MFC_OPENAI_KEY_NAME || "OPENAI_API_KEY_MFC_NEW").trim();
  const raw = (process.env[KEY_NAME] as string | undefined) || "";
  const clean = raw.replace(/^\uFEFF/, "").replace(/[\u200B-\u200D\uFEFF]/g, "").trim();
  if (!clean) throw new Error(`Missing OpenAI key in ${KEY_NAME}`);
  return clean;
}

export async function POST(req: NextRequest) {
  const { prompt } = await req.json().catch(() => ({}));
  if (!prompt || typeof prompt !== "string") {
    return NextResponse.json({ error: "Missing prompt" }, { status: 400 });
  }

  const client = new OpenAI({ apiKey: key() });

  try {
    // OpenAI Images (2025): use "gpt-image-1" and b64_json
    const r = await client.images.generate({
      model: "gpt-image-1",
      prompt,
      size: "1024x1024",
      response_format: "b64_json",
    });
    const b64 = r.data?.[0]?.b64_json;
    if (!b64) return NextResponse.json({ error: "No image returned" }, { status: 502 });
    return NextResponse.json({ base64: b64 });
  } catch (e: any) {
    return NextResponse.json({ error: `OpenAI error: ${e?.message || e}` }, { status: 502 });
  }
}
